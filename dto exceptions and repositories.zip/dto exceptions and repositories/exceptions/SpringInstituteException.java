package com.mediahub.exceptions;

public class SpringInstituteException extends RuntimeException {
    public SpringInstituteException(String exMessage, Exception exception) {
        super(exMessage, exception);
    }

    public SpringInstituteException(String exMessage) {
        super(exMessage);
    }
}
