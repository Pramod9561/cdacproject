package com.mediahub;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Import;
import org.springframework.scheduling.annotation.EnableAsync;

import com.mediahub.config.SwaggerConfiguration;

@SpringBootApplication
@EnableAsync
@Import(SwaggerConfiguration.class)
public class SpringInstituteMediaHub {

    public static void main(String[] args) {

        SpringApplication.run(com.mediahub.SpringInstituteMediaHub.class, args);
    }

}
