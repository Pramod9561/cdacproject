package com.mediahub.exceptions;

public class SpringInvalidException extends RuntimeException {
    public SpringInvalidException(String exMessage, Exception exception) {
        super(exMessage, exception);
    }

    public SpringInvalidException(String exMessage) {
        super(exMessage);
    }
}
