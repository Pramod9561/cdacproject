package com.mediahub.exceptions;

public class PostNotFoundException extends RuntimeException {
    public PostNotFoundException(String message) {
    }
}
