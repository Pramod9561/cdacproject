# angular-reddit-clone
Reddit lke application using Angular, this serves as frontend for the backend API built using Springboot - You can find the source code for backend API here - https://github.com/SaiUpadhyayula/spring-reddit-clone
