export interface LoginRequestPayload {
    username: string;
    password: string;
}

