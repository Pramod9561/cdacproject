export enum VoteType {
    UPVOTE,
    DOWNVOTE
}