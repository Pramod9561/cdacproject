export class CommentPayload{
    text: string;
    postId: number;
    username?:string;
    duration?: string;
}